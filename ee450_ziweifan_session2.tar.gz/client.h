
struct commandInfo {
	char command[1024];
	double bandwidth;
	double length;
	double velocity;
	double noisePower;
	int linkID;
	double size;
	double signalPower;
	double transDelay;
	double propDelay;
};